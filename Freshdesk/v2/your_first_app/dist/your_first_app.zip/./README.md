# Your First App

This app shows the Freshdesk logo and the name of the ticket requester.

![](screenshots/AppOnly.png)

This app demonstrates the following features

1. Using data API to get the ticket requester's details
2. Loading an image from the app folder
